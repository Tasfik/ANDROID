package com.example.calculator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

     Button add_bt,sub_bt,mul_bt,div_bt,adv_bt;
     EditText num1_et,num2_et;
     TextView res_tv;
     String s_num1,s_num2;
     int num1,num2;
     float res;

     private void setId(){
         add_bt=findViewById(R.id.add_bt);
         sub_bt=findViewById(R.id.sub_bt);
         mul_bt=findViewById(R.id.mul_bt);
         div_bt=findViewById(R.id.div_bt);
         adv_bt=findViewById(R.id.adv_bt);

         num1_et=findViewById(R.id.num1_et);
         num2_et=findViewById(R.id.num3_et);

         res_tv=findViewById(R.id.res_tv);
     }

     private boolean setAction(){
         s_num1=num1_et.getText().toString();
         s_num2=num2_et.getText().toString();

         if(s_num1.isEmpty()){
             Toast.makeText(MainActivity.this,"Enter 1st number",Toast.LENGTH_SHORT).show();
             return true;
         }
         else if(s_num2.isEmpty()){
             Toast.makeText(MainActivity.this,"Enter 2nd number",Toast.LENGTH_SHORT).show();
             return true;
         }
         return false;
     }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setId();

        add_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!setAction()){
                    num1=Integer.parseInt(s_num1);
                    num2=Integer.parseInt(s_num2);

                    res=num1+num2;
                    res_tv.setText(String.valueOf(res));
                }
            }
        });

        sub_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!setAction()){
                    num1=Integer.parseInt(s_num1);
                    num2=Integer.parseInt(s_num2);

                    res=num1-num2;
                    res_tv.setText(String.valueOf(res));
                }
            }
        });

        mul_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!setAction()){
                    num1=Integer.parseInt(s_num1);
                    num2=Integer.parseInt(s_num2);

                    res=num1*num2;
                    res_tv.setText(String.valueOf(res));
                }
            }
        });

        div_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!setAction()){
                    num1=Integer.parseInt(s_num1);
                    num2=Integer.parseInt(s_num2);

                    res=(float)num1/num2;
                    res_tv.setText(String.valueOf(res));
                }
            }
        });

        adv_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(MainActivity.this,advance_calc.class);
                startActivity(intent);
            }
        });
    }
}
