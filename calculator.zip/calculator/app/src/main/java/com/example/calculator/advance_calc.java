package com.example.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.*;

public class advance_calc extends AppCompatActivity {

    Button sine_bt,cos_bt,sec_bt,tan_bt,pwr_bt,root_bt;
    EditText num3_et,pwr_et,root_et;
    TextView res2_tv;
    String s_num3,s_pwr,s_root,result;
    double num3,pwr,root;

    double r_num3,d_num3,res2;

    private void setId(){
        sine_bt=findViewById(R.id.sine_bt);
        cos_bt=findViewById(R.id.cos_bt);
        sec_bt=findViewById(R.id.sec_bt);
        tan_bt=findViewById(R.id.tan_bt);
        pwr_bt=findViewById(R.id.pwr_bt);
        root_bt=findViewById(R.id.root_bt);

        num3_et=findViewById(R.id.num3_et);
        pwr_et=findViewById(R.id.pwr_et);
        root_et=findViewById(R.id.root_et);

        res2_tv=findViewById(R.id.res2_tv);

    }

    private boolean setAction(){
        s_num3=num3_et.getText().toString();
        if(s_num3.isEmpty()){
            Toast.makeText(advance_calc.this,"Enter 1st number",Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advance_calc);
        setId();


        sine_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!setAction()){
                    num3=Integer.parseInt(s_num3);
                    r_num3=Math.toRadians(num3);

                    res2=Math.sin(r_num3);
                    result = String.format("%.2f", res2);
                    System.out.println("res1212="+res2);
                    res2_tv.setText(String.valueOf(result));
                }
            }
        });

        cos_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!setAction()){
                    num3=Integer.parseInt(s_num3);
                    r_num3=Math.toRadians(num3);

                    res2=Math.cos(r_num3);
                    result = String.format("%.2f", res2);
                    System.out.println("res1212="+res2);
                    res2_tv.setText(String.valueOf(result));
                }
            }
        });

        sec_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!setAction()){
                    num3=Integer.parseInt(s_num3);
                    r_num3=Math.toRadians(num3);

                    res2=1/(Math.cos(r_num3));
                    result = String.format("%.2f", res2);
                    System.out.println("res1212="+res2);
                    res2_tv.setText(String.valueOf(result));
                }
            }
        });

        tan_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!setAction()){
                    num3=Integer.parseInt(s_num3);
                    r_num3=Math.toRadians(num3);

                    res2=(Math.sin(r_num3))/(Math.cos(r_num3));
                    result = String.format("%.2f", res2);
                    System.out.println("res1212="+res2);
                    res2_tv.setText(String.valueOf(result));
                }
            }
        });

        pwr_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!setAction()){
                    num3=Integer.parseInt(s_num3);
                    s_pwr=pwr_et.getText().toString();
                    if(s_pwr.isEmpty()){
                        Toast.makeText(advance_calc.this,"Enter power",Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        pwr=Integer.parseInt(s_pwr);
                        res2=Math.pow(num3,pwr);
                        res2_tv.setText(String.valueOf(res2));
                    }

                }
            }
        });

        root_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!setAction()){
                    num3=Integer.parseInt(s_num3);
                    s_root=root_et.getText().toString();
                    if(s_root.isEmpty()){
                        Toast.makeText(advance_calc.this,"Enter root value",Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        root=Integer.parseInt(s_root);
                        res2=Math.pow(num3,1/root);
                        result = String.format("%.2f", res2);
                        res2_tv.setText(String.valueOf(result));
                    }


                }
            }
        });


    }
}
